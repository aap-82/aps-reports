# aps-reports

Sample report library for Access Property Services Pty Ltd, deployed to Cloudflare Workers as static assets.

## Layout

```
.
├── wrangler.jsonc          Worker + static-assets config
└── public/                 Everything served from the worker
    ├── index.html          The showcase landing page
    ├── aps-logo.svg        Brand mark used in the topbar
    └── Final_Defects_Inspection_Report_*.html  Live sample report
```

## Deploy

The deploy is wired through Cloudflare's Workers Builds, triggered on every push to `main`. Locally:

```bash
npx wrangler deploy
```

## Add another sample report

1. Drop the HTML file into `public/`.
2. Open `public/index.html`, copy one of the `is-coming` cards, swap the title, description, and tag, and change the surrounding `<div>` to `<a class="report-card" href="./your-new-report.html">` so it becomes clickable.
3. Optionally change the `report-badge is-soft` to a `report-badge` to mark it Live.
4. Commit and push.
